package com.example.personmanagement.employee.model;

import com.example.personmanagement.person.model.PersonDto;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;
import lombok.experimental.SuperBuilder;

import java.time.LocalDate;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@SuperBuilder
@ToString(callSuper = true)
public class EmployeeDto extends PersonDto {
    private LocalDate employmentStartDate;
    private String currentPosition;
    private double currentSalary;
    private int numberOfJobPositions;
}
