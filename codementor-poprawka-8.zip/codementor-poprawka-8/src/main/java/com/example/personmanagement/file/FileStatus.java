package com.example.personmanagement.file;

public enum FileStatus {
    PENDING,
    SUCCESS,
    FAILED
}
