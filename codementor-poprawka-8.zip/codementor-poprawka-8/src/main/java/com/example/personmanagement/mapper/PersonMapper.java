package com.example.personmanagement.mapper;

import com.example.personmanagement.person.model.CreatePersonCommand;
import com.example.personmanagement.person.model.Person;
import com.example.personmanagement.person.model.PersonDto;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
@RequiredArgsConstructor
public class PersonMapper {

    private final List<PersonTypeMapper> mappers;


    public PersonDto toDto(Person person) {
        for (PersonTypeMapper mapper : mappers) {
            if (mapper.supports(person.getType())) {
                return mapper.toDto(person);
            }
        }
        throw new IllegalArgumentException("Unsupported type!");
    }

    public Person fromDto(CreatePersonCommand command) {
        for (PersonTypeMapper mapper : mappers) {
            if (mapper.supports(command.getType())) {
                return mapper.fromDto(command);
            }
        }
        throw new IllegalArgumentException("Unsupported type!");
    }

}