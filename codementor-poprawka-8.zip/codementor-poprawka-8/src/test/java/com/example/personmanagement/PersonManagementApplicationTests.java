package com.example.personmanagement;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PersonManagementApplicationTests {

    @Test
    void contextLoads() {
    }

}
